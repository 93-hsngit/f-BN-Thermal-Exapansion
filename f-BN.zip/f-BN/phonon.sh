#!/bin/bash

rm *.dat

for i in volume-*
do
        cd $i
                phonopy -f disp-{001..200}/vasprun.xml
		rm thermal_properties.*

                phonopy --dim="1 1 1" -c POSCAR -t -p -s ../mesh.conf | tee thermal.out &
		

        cd ../
done



# calculate the volume vs energy (e-v.dat and fe-v.dat)
phonopy-vasp-efe --tmax=2000 volume-0.98/disp-{001..200}/vasprun.xml volume-0.99/disp-{001..200}/vasprun.xml volume-1.00/disp-{001..200}/vasprun.xml volume-1.01/disp-{001..200}/vasprun.xml volume-1.02/disp-{001..200}/vasprun.xml volume-1.03/disp-{001..200}/vasprun.xml volume-1.04/disp-{001..200}/vasprun.xml volume-1.05/disp-{001..200}/vasprun.xml volume-1.06/disp-{001..200}/vasprun.xml
# e-v.dat murnaghan fitting
#phonopy-qha -b e-v.dat --eos murnaghan -p

# QHA calculation (all thermodynamic properties)
bash min.sh 
phonopy-qha -b e-v_new.dat --eos murnaghan -p   & 

phonopy-qha -p --tmax=2000 e-v_new.dat volume-0.98/thermal_properties.yaml volume-0.99/thermal_properties.yaml volume-1.00/thermal_properties.yaml volume-1.01/thermal_properties.yaml volume-1.02/thermal_properties.yaml volume-1.03/thermal_properties.yaml volume-1.04/thermal_properties.yaml volume-1.05/thermal_properties.yaml volume-1.06/thermal_properties.yaml

cp thermal_expansion.dat CTE_12121.dat
mv CTE_12121.dat cte/ 
